<!-- footer.php -->
    <!-- JavaScript -->
    <script src="<?php echo BASE_URL; ?>assets/js/jquery-3.5.1.slim.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/row_edit.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/delete.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/script.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/bulk_delete.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/sidebar.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/delete_user.js"></script>
</body>
</html>
