<?php
session_start();
$host = $_SESSION['host'];
$database = $_SESSION['database'];
$db_username = $_SESSION['db_username'];
$db_password = $_SESSION['db_password'];

$conn = new mysqli($host, $db_username, $db_password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_file = 'db.sql';
$sql = file_get_contents($sql_file);

if ($conn->multi_query($sql)) {
    do {
    } while ($conn->next_result());
    header("Location: process.php");
    exit;
} else {
    die("Error importing database: " . $conn->error);
}

$conn->close();
?>
