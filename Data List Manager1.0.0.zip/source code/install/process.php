<?php
session_start();

$host = $_SESSION['host'];
$database = $_SESSION['database'];
$db_username = $_SESSION['db_username'];
$db_password = $_SESSION['db_password'];

// Detect the protocol (http or https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https://" : "http://";

// Get the host (e.g., google.com)
$host_u = $_SERVER['HTTP_HOST'];

// Get the folder path for `datamanagertables`
$base_path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

// Fix the base path to remove `/includes/` since you moved `config.php`
if (basename($base_path) === 'install') {
    $base_path = dirname($base_path);
}

// If the base path is empty, default it to '/'
if ($base_path === '/') {
    $base_path = '';
}

// Construct the BASE_URL
define('BASE_URL', $protocol . $host_u . $base_path . '/');

$host_url = BASE_URL;

$config_content = <<<PHP
<?php
\$host = '$host';
\$db_username = '$db_username';
\$db_password = '$db_password';
\$database = '$database';

\$conn = new mysqli(\$host, \$db_username, \$db_password, \$database);
if (\$conn->connect_error) {
    die("Connection failed: " . \$conn->connect_error);
}

define('BASE_URL', '$host_url');
?>

PHP;

if (file_put_contents('../includes/db.php', $config_content)) {
    header("Location: ../includes/success.php");
    exit;
} else {
    die("Failed to write configuration file.");
}
?>
