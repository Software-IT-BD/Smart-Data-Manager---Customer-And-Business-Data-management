CREATE TABLE `customers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `address` TEXT NOT NULL,
  `email` TEXT NOT NULL,
  `phone` TEXT NOT NULL,
  `website` TEXT NOT NULL,
  `social_media` TEXT NOT NULL,
  `note` TEXT NOT NULL,
  `status` TEXT NOT NULL
) ENGINE=InnoDB;
