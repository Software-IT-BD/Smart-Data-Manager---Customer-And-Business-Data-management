<?php
session_start();
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $host = $_POST['host'];
    $database = $_POST['database'];
    $db_username = $_POST['db_username'];
    $db_password = $_POST['db_password'];
    $user_full_name = $_POST['user_full_name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];

    $_SESSION['host'] = $host;
    $_SESSION['database'] = $database;
    $_SESSION['db_username'] = $db_username;
    $_SESSION['db_password'] = $db_password;

    try {
        $conn = new mysqli($host, $db_username, $db_password, $database);
        if ($conn->connect_error) {
            throw new Exception("Database connection failed: " . $conn->connect_error);
        }

        $create_users_table = "CREATE TABLE IF NOT EXISTS `users` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_full_name` VARCHAR(250) NOT NULL,
            `username` VARCHAR(100) NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `email` VARCHAR(100),
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;";

        if (!$conn->query($create_users_table)) {
            throw new Exception("Error creating table: " . $conn->error);
        }

        $stmt = $conn->prepare("INSERT INTO `users` (`user_full_name`, `username`, `password`, `email`) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_full_name, $username, $password, $email);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting user: " . $stmt->error);
        }

        $stmt->close();
        $conn->close();
        header("Location: step2.php");
        exit;
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Database</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Install Database</h1>
    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="card">
            <div class="card-body">
                <h3>Database Configuration</h3>
                <input type="text" name="host" value="localhost" class="form-control mb-3" placeholder="Host Name" required>
                <input type="text" name="database" class="form-control mb-3" placeholder="Database Name" required>
                <input type="text" name="db_username" class="form-control mb-3" placeholder="Database Username" required>
                <input type="password" name="db_password" class="form-control mb-3" placeholder="Database Password">
                <h3>Create Admin User</h3>
                <input type="text" name="user_full_name" class="form-control mb-3" placeholder="Full Name" required>
                <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
                <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
                <input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>
</body>
</html>
