
# Data List Manager - Customer And Business Data list management

**Data List Manager** is a powerful and user-friendly system designed to help businesses and organizations store, manage, and organize their customer and business data. With easy-to-use features such as data addition, editing, deletion, and secure search options, this tool is perfect for managing customer information and business operations.

---

## Features

- **Add, Edit, and Delete Data**: Easily manage customer and business data.
- **Search & Filter**: Quickly search and filter data by various parameters.
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices.
- **Export Data to CSV**: Export your data to CSV format for reporting and backup purposes.
- **User Authentication**: Secure login and access control to protect your data.
- **Customizable Fields**: Create custom fields to match your data management needs.
- **Bootstrap Powered UI**: A modern and elegant user interface using Bootstrap 5.
- **Simple Setup**: Easy to install and configure.

---

## Installation Guide

### Step 1: Download & Extract Files
- Download the ZIP file containing the Data List Manager from **CodeCanyon**.
- Extract the contents of the ZIP file to your server's root directory.

### Step 2: Server Requirements
Ensure your server meets the following requirements:
- **PHP 7.4 or higher**
- **MySQL 5.6 or higher**
- **Apache or Nginx server**

### Step 3: Create a MySQL Database
1. Log in to your MySQL database server (using phpMyAdmin or the MySQL command line).
2. Create a new database. For example:
   ```sql
   CREATE DATABASE smart_data_manager;
   ```

### Step 4: Configure Database Connection
1. Open the `includes/db.php` file in your project.
2. Update the following parameters with your database credentials:
   ```php
   define('DB_SERVER', 'localhost');  // Change to your MySQL server
   define('DB_USERNAME', 'your_database_username');  // Your database username
   define('DB_PASSWORD', 'your_database_password');  // Your database password
   define('DB_DATABASE', 'smart_data_manager');  // The database you created
   ```

### Step 5: Import Demo Data
1. Use **phpMyAdmin** or the **MySQL command line** to import the `demo.sql` file into your database. This will create the necessary tables and structure.

### Step 6: Access the System
- After uploading the files and setting up the database, access the system via the browser (e.g., `http://your-domain.com`).
- Log in using the admin credentials you set up during installation.

---

## How to Use

1. **Login**: Log in to the system using your admin credentials.
2. **Manage Data**: 
   - Add, edit, or delete customer and business data from the dashboard.
   - Use the "Search" feature to quickly locate records.
3. **Export Data**: Export data to CSV by clicking the "Export to CSV" button in the dashboard.

---

## License

This software is licensed under the [Codecanyon Standard License](http://codecanyon.net/licenses). You may use it for personal or commercial purposes, but redistribution or resale of the software is prohibited.

---

## FAQ

**Q: How do I reset my password?**
- A: If you have forgotten your password, click the "Forgot Password" link on the login page to reset it.

**Q: How do I add a new user?**
- A: Navigate to the "User Management" section in the dashboard and click "Add User" to create a new user account.

**Q: How do I export my data?**
- A: You can export your data to CSV by clicking the "Export to CSV" button on the dashboard.

---

## Support

For any support or queries, contact us at:

- Email: [support@softwareit.com.bd](mailto:support@softwareit.com.bd)

---

## Changelog

### Version 1.0.0
- Initial release of Data List Manager.

---

## Credits

- **Bootstrap**: Frontend framework used for responsive design ([https://getbootstrap.com](https://getbootstrap.com)).
- **Font Awesome**: Icons library ([https://fontawesome.com](https://fontawesome.com)).

---

© 2024 Software IT. All rights reserved.
