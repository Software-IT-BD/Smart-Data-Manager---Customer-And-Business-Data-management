/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

 
 document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-user-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const userId = this.dataset.id; // Get the user ID
            const row = this.closest('tr'); // Get the row to be deleted

            // Log user ID and row for debugging
            console.log('User ID:', userId);
            console.log('Row:', row);

            // Confirmation dialog
            if (confirm('Are you sure you want to delete this user?')) {
                fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({ delete_user_id: userId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    row.remove();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while deleting the user.');
            });
            }
        });
    });
});