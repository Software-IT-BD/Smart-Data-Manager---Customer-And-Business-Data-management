/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

// Data List Page "Row Edit" functionality
document.addEventListener('DOMContentLoaded', function () {
    const tableSection = document.getElementById('tableDataSection');

    // Use event delegation for edit buttons
    tableSection.addEventListener('click', function (event) {
        if (event.target.classList.contains('edit-btn')) {
            const id = event.target.getAttribute('data-id');
            const editRow = document.getElementById(`edit-row-${id}`);
            // Toggle visibility of the edit row
            if (editRow) {
                editRow.style.display = editRow.style.display === 'none' ? 'table-row' : 'none';
            }
        }
    });

    // Use event delegation for save buttons
    tableSection.addEventListener('click', function (event) {
        if (event.target.classList.contains('save-btn')) {
            const id = event.target.getAttribute('data-id');
            const form = document.getElementById(`edit-form-${id}`);
            if (form) {
                const formData = new FormData(form);

                // Send data to the server using Fetch API
                fetch("includes/row_edit.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Row updated successfully!");
                            location.reload(); // Reload to reflect changes
                        } else {
                            alert("Error updating row: " + (data.error || "Unknown error"));
                        }
                    })
                    .catch(error => console.error("Error:", error));
            }
        }
    });
});
