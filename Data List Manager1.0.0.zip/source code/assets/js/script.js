/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

// Select All checkbox functionality
document.getElementById("select-all").addEventListener("change", function() {
    // Get the state of the "Select All" checkbox (checked or unchecked)
    const isChecked = this.checked;

    // Select all checkboxes with the name "selectRow" inside the table
    const checkboxes = document.querySelectorAll("#data-table tbody input[name='selectRow']");

    // Loop through each checkbox and set its checked state to match the "Select All" checkbox
    checkboxes.forEach(function(checkbox) {
        checkbox.checked = isChecked;
    });
});

// Select all individual checkboxes with the name "selectRow"
const rowCheckboxes = document.querySelectorAll("#data-table tbody input[name='selectRow']");

// Loop through each row checkbox and add a change event listener
rowCheckboxes.forEach(function(checkbox) {
    checkbox.addEventListener("change", function() {
        // Get the "Select All" checkbox
        const selectAllCheckbox = document.getElementById("select-all");

        // Check if all row checkboxes are checked
        const allChecked = Array.from(rowCheckboxes).every(function(checkbox) {
            return checkbox.checked;
        });

        // Set the "Select All" checkbox to checked if all are checked, otherwise set it to unchecked
        selectAllCheckbox.checked = allChecked;
    });
});

// JavaScript for select-all functionality
document.addEventListener('DOMContentLoaded', function () {
    const selectAllCheckbox = document.getElementById('select-all');
    const checkboxes = document.querySelectorAll('input[name="selectRow"]');

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function () {
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
    }
});

// Data List bulk Update
function bulkUpdateField(field) {
    // Collect all selected rows
    const selectedIds = Array.from(document.querySelectorAll("#data-table tbody input[name='selectRow']:checked")).map(checkbox => checkbox.value);

    if (selectedIds.length === 0) {
        alert("Please select at least one row to update.");
        return;
    }

    // Determine the new value based on the field to update
    let newValue;
    if (field === 'name') {
        newValue = document.getElementById("bulk-name").value;
    } else if (field === 'company_name') {
        newValue = document.getElementById("bulk-company_name").value;
    } else if (field === 'address') {
        newValue = document.getElementById("bulk-address").value;
    } else if (field === 'email') {
        newValue = document.getElementById("bulk-email").value;
    } else if (field === 'phone') {
        newValue = document.getElementById("bulk-phone").value;
    } else if (field === 'website') {
        newValue = document.getElementById("bulk-website").value;
    } else if (field === 'social_media') {
        newValue = document.getElementById("bulk-social_media").value;
    } else if (field === 'note') {
        newValue = document.getElementById("bulk-note").value;
    } else if (field === 'status') {
        newValue = document.getElementById("bulk-status").value;
    }

    if (!newValue) {
        alert("Please provide a new value for " + field);
        return;
    }

    // Send AJAX request for bulk update
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "includes/bulk_update.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.responseText);
            // Optionally, reload the data table after update
            location.reload();
        }
    };
    xhr.send("field=" + field + "&newValue=" + newValue + "&ids=" + JSON.stringify(selectedIds));
}

// Data List Search and Filter

document.getElementById('apply-filters').addEventListener('click', function() {
// Get filter values
const name = document.getElementById('name').value || '';
const company_name = document.getElementById('company_name').value || '';
const address = document.getElementById('address').value || '';
const email = document.getElementById('email').value || '';
const phone = document.getElementById('phone').value || '';
const website = document.getElementById('website').value || '';
const social_media = document.getElementById('social_media').value || '';
const note = document.getElementById('note').value || '';
const status = document.getElementById('status').value || '';

// Create AJAX request
const xhr = new XMLHttpRequest();
xhr.open('GET', 'includes/filter_data.php?name=' + encodeURIComponent(name) +
    '&company_name=' + encodeURIComponent(company_name) +
    '&address=' + encodeURIComponent(address) +
    '&email=' + encodeURIComponent(email) +
    '&phone=' + encodeURIComponent(phone) +
    '&website=' + encodeURIComponent(website) +
    '&social_media=' + encodeURIComponent(social_media) +
    '&note=' + encodeURIComponent(note) +
    '&status=' + encodeURIComponent(status), true);

xhr.onload = function() {
    if (xhr.status === 200) {
        // Update the table with the filtered data
        document.querySelector('tbody').innerHTML = xhr.responseText;
    } else {
        alert('Error applying filters');
    }
};

xhr.send();
});

//  pagination and Bulk Delete
document.addEventListener("DOMContentLoaded", () => {
    const tableSection = document.getElementById("tableDataSection");
    const rowsPerPageForm = document.getElementById("rows-per-page-form");
    const selectAllCheckbox = document.getElementById("select-all");

    // Initial Fetch
    fetchData();

    /**
     * Fetch table data via AJAX
     */
    function fetchData(page = 1, rowsPerPage = 10) {
        const filters = {
            name: document.getElementById("name")?.value || "",
            company_name: document.getElementById("company_name")?.value || "",
            address: document.getElementById("address")?.value || "",
            email: document.getElementById("email")?.value || "",
            phone: document.getElementById("phone")?.value || "",
            website: document.getElementById("website")?.value || "",
            social_media: document.getElementById("social_media")?.value || "",
            note: document.getElementById("note")?.value || "",
            status: document.getElementById("status")?.value || "",
        };

        const queryParams = new URLSearchParams({
            ...filters,
            rowsPerPage: rowsPerPage,
            page: page,
        });

        fetch(`includes/filter_data.php?${queryParams.toString()}`)
            .then((response) => response.text())
            .then((data) => {
                document.querySelector("#data-table tbody").innerHTML = data;
                updatePaginationState(page);
                reinitializeEventListeners(); // Rebind necessary event listeners
            })
            .catch((error) => console.error("Error fetching data:", error));
    }

    /**
     * Reinitialize event listeners for dynamically added elements
     */
    function reinitializeEventListeners() {
        bindRowCheckboxLogic(); // Rebind checkbox logic
        bindDeleteButtonLogic(); // Rebind delete button logic
    }

    /**
     * Bind logic for row checkboxes and bulk actions
     */
    function bindRowCheckboxLogic() {
        const rowCheckboxes = document.querySelectorAll("input[name='selectRow']");

        // Select All Checkbox Logic
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener("change", () => {
                rowCheckboxes.forEach((checkbox) => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });
        }
    }

    /**
     * Rebind Delete Button Logic
     */
    function bindDeleteButtonLogic() {
        const deleteButton = document.querySelector(".btn-danger.w-100");
        if (deleteButton) {
            deleteButton.replaceWith(deleteButton.cloneNode(true)); // Remove old listeners
            const newDeleteButton = document.querySelector(".btn-danger.w-100");

            newDeleteButton.addEventListener("click", () => {
                const rowCheckboxes = document.querySelectorAll("input[name='selectRow']");
                const selectedIds = Array.from(rowCheckboxes)
                    .filter((checkbox) => checkbox.checked)
                    .map((checkbox) => checkbox.value);

                if (selectedIds.length === 0) {
                    alert("Please select at least one row to delete.");
                    return;
                }

                if (confirm("Are you sure you want to delete the selected rows?")) {
                    fetch("includes/bulk_delete.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ ids: selectedIds }),
                    })
                        .then((response) => {
                            if (!response.ok) throw new Error("Network error");
                            return response.json();
                        })
                        .then((data) => {
                            if (data.success) {
                                alert("Selected rows deleted successfully!");
                                selectedIds.forEach((id) => {
                                    const row = document.querySelector(`tr[data-id="${id}"]`);
                                    if (row) row.remove();
                                });
                            } else {
                                alert("Error: " + (data.error || "Unknown error occurred."));
                            }
                        })
                        .catch((error) => console.error("Error:", error));
                }
            });
        }
    }

    /**
     * Update active pagination button state
     */
    function updatePaginationState(activePage) {
        const paginationButtons = document.querySelectorAll(".pagination-btn");
        paginationButtons.forEach((btn) => {
            if (parseInt(btn.getAttribute("data-page"), 10) === parseInt(activePage, 10)) {
                btn.classList.add("active");
            } else {
                btn.classList.remove("active");
            }
        });
    }

    /**
     * Handle rows per page change
     */
    rowsPerPageForm?.addEventListener("submit", (event) => {
        event.preventDefault();
        const rowsPerPage = parseInt(document.getElementById("rowsPerPage").value, 10) || 10;
        fetchData(1, rowsPerPage); // Reset to page 1
    });

    /**
     * Handle pagination button clicks
     */
    tableSection.addEventListener("click", (event) => {
        if (event.target.classList.contains("pagination-btn")) {
            const page = parseInt(event.target.getAttribute("data-page"), 10);
            const rowsPerPage = parseInt(document.getElementById("rowsPerPage").value, 10) || 10;
            fetchData(page, rowsPerPage);
        }
    });

    // Apply Filter Button Logic
    document.getElementById("apply-filters").addEventListener("click", () => {
        fetchData(); // Re-fetch data with filters applied
    });
});

// Header Drop Down
document.addEventListener("DOMContentLoaded", () => {
    const dropdown = document.querySelector(".dropdown");

    dropdown.addEventListener("mouseenter", () => {
        const menu = dropdown.querySelector(".dropdown-menu");
        menu.classList.add("show");
    });

    dropdown.addEventListener("mouseleave", () => {
        const menu = dropdown.querySelector(".dropdown-menu");
        menu.classList.remove("show");
    });
});

