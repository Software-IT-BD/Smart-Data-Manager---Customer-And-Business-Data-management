     
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

// sidebar hidden 
const sidebar = document.getElementById('sidebar');
const mainContent = document.getElementById('main-content');
const headertogglesidebar = document.getElementById('header-toggle-sidebar');
const headerfullscreen = document.getElementById('header_fullscreen');
const toggleButton = document.getElementById('toggle-sidebar');
const closeSidebarButton = document.getElementById('close-sidebar');

// Mobile Sidebar Toggle
toggleButton.addEventListener('click', () => {
    sidebar.classList.toggle('active');  // Toggle sidebar visibility on mobile

    // Adjust the main content when sidebar is toggled
    if (sidebar.classList.contains('active')) {
        mainContent.classList.add('fullscreen');
        headerfullscreen.classList.add('fullscreen');
        closeSidebarButton.style.display = 'block';  // Show close button when sidebar is open
    } else {
        mainContent.classList.remove('fullscreen');
        headerfullscreen.classList.remove('fullscreen');
        closeSidebarButton.style.display = 'none';  // Hide close button when sidebar is closed
    }
});

// Close Sidebar Button (Mobile only)
closeSidebarButton.addEventListener('click', () => {
    sidebar.classList.remove('active');  // Hide sidebar
    mainContent.classList.remove('fullscreen');  // Reset the main content width
    headerfullscreen.classList.remove('fullscreen');  // Reset the main content width
    closeSidebarButton.style.display = 'none';  // Hide close button
});

// Manage Sidebar Toggle for Desktop
const desktopSidebarToggle = document.createElement('button');
desktopSidebarToggle.innerText = '☰';
desktopSidebarToggle.classList.add('btn', 'btn-primary', 'mobile_button');

// Insert desktop toggle button into the main content
headertogglesidebar.insertBefore(desktopSidebarToggle, headertogglesidebar.firstChild);

desktopSidebarToggle.addEventListener('click', () => {
    if (window.innerWidth > 768) { // Check if on desktop
        sidebar.classList.toggle('hidden');  // Hide the sidebar on desktop
        mainContent.classList.toggle('fullscreen');
        headerfullscreen.classList.toggle('fullscreen');
    }
});