/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

// Data List Page "Data Delete" functionality
document.addEventListener("click", function (e) {
    if (e.target.classList.contains("delete-btn")) {
        const id = e.target.dataset.id;

        if (confirm("Are you sure you want to delete this record?")) {
            fetch("includes/delete.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        e.target.closest("tr").remove();
                        alert("Record deleted successfully!");
                    } else {
                        alert("Error deleting record.");
                    }
                });
        }
    }
});
