<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include '../includes/db.php';

// Error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user_id'])) {
    $user_id = $_POST['delete_user_id'];

    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Error preparing SQL statement: ' . $conn->error]);
        exit;
    }

    $stmt->bind_param("i", $user_id);

    try {
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo json_encode(['success' => true, 'message' => 'User deleted successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'User ID not found or already deleted.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Error deleting user: ' . $stmt->error]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Exception: ' . $e->getMessage()]);
    } finally {
        $stmt->close();
    }

    exit;
}

$sql = "SELECT id, user_full_name, username, email, created_at FROM users";
$result = $conn->query($sql);
include '../header.php';
?>
<div class="d-flex">
    <!-- Sidebar -->
    <?php
        include '../sidebar.php';
    ?>
    <div class="container-fluid p-4 main-content" id="main-content">
        <h2 class="mb-4">User List</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_full_name']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                        <td>
                            <a href="edit_user.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <button class="btn btn-danger btn-sm delete-user-btn" data-id="<?php echo $row['id']; ?>">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="add_user.php" class="btn btn-primary">Add User</a>
    </div>
</div>
<?php
// Including the footer
include '../footer.php';
include '../includes/delete_user.php';
?>