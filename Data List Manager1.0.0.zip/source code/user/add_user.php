<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include '../includes/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_full_name = $conn->real_escape_string($_POST['user_full_name']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt the password

    // Check for existing username or email
    $check_sql = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        $message = "Error: Username or Email already exists. Please use a different one.";
    } else {
        // Proceed with inserting new user
        $sql = "INSERT INTO users (user_full_name, username, password, email) VALUES ('$user_full_name', '$username', '$password', '$email')";

        if ($conn->query($sql) === TRUE) {
            $message = "User added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}
include '../header.php';
?>
<div class="d-flex">
    <!-- Sidebar -->
    <?php
		include '../sidebar.php';
	?>
    <div class="container-fluid p-4 main-content" id="main-content">
        <h2 class="mb-4">Add User</h2>

        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" class="shadow p-4 rounded bg-light">
            <div class="mb-3">
                <label for="user_full_name" class="form-label">User Full Name</label>
                <input type="text" name="user_full_name" id="user_full_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add User</button>
        </form>
     </div>
</div>

<?php
// Including the footer
include '../footer.php';
?>
