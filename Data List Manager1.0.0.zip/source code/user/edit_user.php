<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include '../includes/db.php';

$message = '';
$id = $_GET['id'];

// Fetch user details
$sql = "SELECT * FROM users WHERE id = $id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_full_name = $conn->real_escape_string($_POST['user_full_name']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    
    // Check if the password is being changed
    if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        // Check if new password matches the confirmation
        if ($_POST['new_password'] === $_POST['confirm_password']) {
            // Hash the new password
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            
            // Update the password in the database
            $update_sql = "UPDATE users SET password = '$new_password' WHERE id = $id";
            $conn->query($update_sql);
            $message = "Password updated successfully!";
        } else {
            $message = "New password and confirmation do not match.";
        }
    }

    // Update user details
    $update_sql = "UPDATE users SET user_full_name = '$user_full_name', username = '$username', email = '$email' WHERE id = $id";

    if ($conn->query($update_sql) === TRUE) {
        $message .= " User updated successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
include '../header.php';
?>
<div class="d-flex">
    <!-- Sidebar -->
    <?php
		include '../sidebar.php';
	?>
    <div class="container-fluid p-4 main-content" id="main-content">
        <h2 class="mb-4">Edit User</h2>

        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="user_full_name" class="form-label">Full Name</label>
                <input type="text" name="user_full_name" id="user_full_name" class="form-control" value="<?php echo $user['user_full_name']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" class="form-control" value="<?php echo $user['username']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo $user['email']; ?>" required>
            </div>

            <!-- Password Change Section -->
            <h4 class="mt-4">Change Password</h4>
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" name="new_password" id="new_password" class="form-control">
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" name="confirm_password" id="confirm_password" class="form-control">
            </div>

            <button type="submit" class="btn btn-success">Update User</button>
            <a href="user_list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
<?php
// Including the footer
include '../footer.php';
?>