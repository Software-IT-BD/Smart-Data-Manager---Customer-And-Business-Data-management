<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include '../includes/db.php';

require '../vendor/autoload.php'; // If using Composer, include this line

use PhpOffice\PhpSpreadsheet\IOFactory;

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['excel_file'])) {
    $file = $_FILES['excel_file'];

    // Check for file upload errors
    if ($file['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $file['tmp_name'];
        $fileName = $file['name'];

        // Ensure it's an Excel file
        $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
        if ($fileExtension !== 'xlsx' && $fileExtension !== 'xls') {
            $message = "Please upload a valid Excel file (xlsx or xls).";
        } else {
            try {
                // Load the uploaded Excel file
                $spreadsheet = IOFactory::load($fileTmpPath);
                $sheet = $spreadsheet->getActiveSheet();
                $rows = $sheet->toArray();

                // Skip the header row (row 1)
                $rows = array_slice($rows, 1);

                // Process each row and insert into the database
                foreach ($rows as $row) {
                    // Ensure all necessary columns exist and handle empty values
                    $name = isset($row[0]) ? $conn->real_escape_string($row[0]) : NULL;
                    $company_name = isset($row[1]) ? $conn->real_escape_string($row[1]) : NULL;
                    $address = isset($row[2]) ? $conn->real_escape_string($row[2]) : NULL;
                    $email = isset($row[3]) ? $conn->real_escape_string($row[3]) : NULL;
                    $phone = isset($row[4]) ? $conn->real_escape_string($row[4]) : NULL;
                    $website = isset($row[5]) ? $conn->real_escape_string($row[5]) : NULL;
                    $social_media = isset($row[6]) ? $conn->real_escape_string($row[6]) : NULL;
                    $note = isset($row[7]) ? $conn->real_escape_string($row[7]) : NULL;
                    $status = isset($row[8]) ? strtolower(trim($conn->real_escape_string($row[8]))) : NULL;

                    // Insert data into the database
                    $sql = "INSERT INTO customers (name, company_name, address, email, phone, website, social_media, note, status)
                            VALUES ('$name', '$company_name', '$address', '$email', '$phone', '$website', '$social_media', '$note', '$status')";

                    if (!$conn->query($sql)) {
                        $message = "Error inserting data: " . $conn->error;
                        break;
                    }
                }

                $message = "Customer data has been successfully imported from the Excel file!";
            } catch (Exception $e) {
                $message = "Error processing the Excel file: " . $e->getMessage();
            }
        }
    } else {
        $message = "Error uploading file. Please try again.";
    }
}
include '../header.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <?php
		include '../sidebar.php';
	?>
    <div class="container-fluid p-4 main-content" id="main-content">
        <h2 class="mb-4">Upload Customer Data from Excel</h2>
        <button class="btn btn-primary" ><a href="../uploads/Demo.xlsx" style="padding: 0px;" class="btn btn-primary" download>Download Demo Excel File</a>
        </button><br><br>
        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="shadow p-4 rounded bg-light">
            <div class="mb-3">
                <label for="excel_file" class="form-label">Select Excel File (xlsx or xls)</label>
                <input type="file" name="excel_file" id="excel_file" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload and Import Data</button>
        </form>
    </div>
</div>
<?php
// Including the footer
include '../footer.php';
?>
