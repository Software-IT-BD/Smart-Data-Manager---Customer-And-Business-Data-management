<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include '../includes/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $company_name = $conn->real_escape_string($_POST['company_name']);
    $address = $conn->real_escape_string($_POST['address']);
    $email = $conn->real_escape_string($_POST['email']);
	$phone = $conn->real_escape_string($_POST['phone']);
	$website = $conn->real_escape_string($_POST['website']);
	$social_media = $conn->real_escape_string($_POST['social_media']);
	$note = $conn->real_escape_string($_POST['note']);
	$status = $conn->real_escape_string($_POST['status']);

    $sql = "INSERT INTO customers (name, company_name, address, email, phone, website, social_media, note, status) VALUES ('$name', '$company_name', '$address', '$email', '$phone', '$website', '$social_media', '$note', '$status')";

    if ($conn->query($sql)) {
        $message = "Customer added successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}

include '../header.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <?php
		include '../sidebar.php';
	?>
    <div class="container-fluid p-4 main-content" id="main-content">
        <h2 class="mb-4">Add Data</h2>

        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" class="shadow p-4 rounded bg-light">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="company_name" class="form-label">Company Name</label>
                <input type="text" name="company_name" id="company_name" class="form-control">
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <textarea name="address" id="address" class="form-control" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="text" name="email" id="email" class="form-control">
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" name="phone" id="phone" class="form-control">
            </div>
            <div class="mb-3">
                <label for="website" class="form-label">Website</label>
                <input type="text" name="website" id="website" class="form-control">
            </div>
            <div class="mb-3">
                <label for="social_media" class="form-label">Social Media</label>
                <textarea name="social_media" id="social_media" class="form-control" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="note" class="form-label">Note</label>
                <textarea name="note" id="note" class="form-control" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select name="status" id="status" class="form-select">
                    <option value="good">Good</option>
                    <option value="bad">Bad</option>
                    <option value="approved">Approved</option>
                    <option value="verified">Verified</option>
                    <option value="ongoing">Ongoing</option>
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="under_review">Under Review</option>
                    <option value="awaiting_approval">Awaiting Approval</option>
                    <option value="processing">Processing</option>
                    <option value="on_hold">On hold</option>
                    <option value="successful">Successful</option>
                    <option value="complete">Complete</option>
                    <option value="cancelled">Cancelled</option>
                    <option value="refunded">Refunded</option>
                    <option value="failed">Failed</option>
                    <option value="expired">Expired</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Add Customer</button>
        </form>
    </div>      
</div>

<?php
// Including the footer
include '../footer.php';
?>