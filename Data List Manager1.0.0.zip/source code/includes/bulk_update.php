<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include 'db.php'; // Adjust the path as needed


// Data List Page "Bulk Update" functionality

// Check if required parameters are set
if (!isset($_POST['field'], $_POST['newValue'], $_POST['ids'])) {
    echo "Error: Missing required parameters.";
    exit;
}

$field = $_POST['field'];
$newValue = $_POST['newValue'];
$ids = json_decode($_POST['ids'], true);

// Validate the field to ensure it's a valid column
$validFields = ['name', 'company_name', 'address', 'email', 'phone', 'website', 'social_media', 'note', 'status'];
if (!in_array($field, $validFields)) {
    echo "Error: Invalid field.";
    exit;
}

// Prepare the SQL query for bulk updating
$idList = implode(',', array_map('intval', $ids)); // Sanitize IDs for SQL
$sql = "UPDATE customers SET $field = ? WHERE id IN ($idList)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $newValue);

// Execute the query
if ($stmt->execute()) {
    echo "Records updated successfully.";
} else {
    echo "Error updating records: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
