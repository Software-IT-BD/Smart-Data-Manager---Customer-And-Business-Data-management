<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['id']) && !empty($data['id'])) {
        $user_id = $data['id'];

        error_log("User ID: $user_id");

        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            error_log("Error preparing SQL statement: " . $conn->error);
            echo json_encode(['success' => false, 'message' => 'Error preparing SQL statement.']);
            exit;
        }

        $stmt->bind_param("i", $user_id);

        try {
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    echo json_encode(['success' => true, 'message' => 'User deleted successfully.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'User ID not found or already deleted.']);
                }
            } else {
                error_log("Error executing delete: " . $stmt->error);
                echo json_encode(['success' => false, 'message' => 'Error deleting user: ' . $stmt->error]);
            }
        } catch (Exception $e) {
            error_log("Exception: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Exception: ' . $e->getMessage()]);
        } finally {
            $stmt->close();
        }
    } else {
        error_log("User ID is missing or invalid.");
        echo json_encode(['success' => false, 'message' => 'User ID is missing or invalid.']);
    }
} 
?>