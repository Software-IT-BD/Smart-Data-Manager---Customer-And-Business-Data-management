<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
include 'db.php';

// Data List Page "Row Edit" functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;

    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'ID is required']);
        exit;
    }

    // Optional fields
    $name = $_POST['name'] ?? null;
    $company_name = $_POST['company_name'] ?? null;
    $address = $_POST['address'] ?? null;
    $email = $_POST['email'] ?? null;
    $phone = $_POST['phone'] ?? null;
    $website = $_POST['website'] ?? null;
    $social_media = $_POST['social_media'] ?? null;
    $note = $_POST['note'] ?? null;
    $status = $_POST['status'] ?? null;

    // Build the query dynamically
    $fields = [];
    $values = [];

    if ($name !== null) {
        $fields[] = 'name = ?';
        $values[] = $name;
    }
    if ($company_name !== null) {
        $fields[] = 'company_name = ?';
        $values[] = $company_name;
    }
    if ($address !== null) {
        $fields[] = 'address = ?';
        $values[] = $address;
    }
    if ($email !== null) {
        $fields[] = 'email = ?';
        $values[] = $email;
    }
    if ($phone !== null) {
        $fields[] = 'phone = ?';
        $values[] = $phone;
    }
    if ($website !== null) {
        $fields[] = 'website = ?';
        $values[] = $website;
    }
    if ($social_media !== null) {
        $fields[] = 'social_media = ?';
        $values[] = $social_media;
    }
    if ($note !== null) {
        $fields[] = 'note = ?';
        $values[] = $note;
    }
    if ($status !== null) {
        $fields[] = 'status = ?';
        $values[] = $status;
    }

    if (!empty($fields)) {
        // Add ID to the values array
        $values[] = $id;

        // Prepare the SQL query
        $query = "UPDATE customers SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $conn->prepare($query);

        // Bind the parameters dynamically
        $stmt->bind_param(str_repeat('s', count($fields)) . 'i', ...$values);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $stmt->error]);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'No fields to update']);
    }

    $conn->close();
}
?>
