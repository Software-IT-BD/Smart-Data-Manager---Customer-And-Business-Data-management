
<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */
// Include the database connection
include 'db.php'; // Adjust the path as needed

// Data List Page "Data Filter" functionality
$id = isset($_GET['id']) ? $_GET['id'] : '';
$name = isset($_GET['name']) ? $_GET['name'] : '';
$company_name = isset($_GET['company_name']) ? $_GET['company_name'] : '';
$address = isset($_GET['address']) ? $_GET['address'] : '';
$email = isset($_GET['email']) ? $_GET['email'] : '';
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';
$website = isset($_GET['website']) ? $_GET['website'] : '';
$social_media = isset($_GET['social_media']) ? $_GET['social_media'] : '';
$note = isset($_GET['note']) ? $_GET['note'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

$rowsPerPage = isset($_GET['rowsPerPage']) ? max((int)$_GET['rowsPerPage'], 1) : 10; // Default to 24 rows per page
$page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1; // Default to page 1

$offset = ($page - 1) * $rowsPerPage;

// Build the query with conditions based on the filters
$query = "SELECT id, name, company_name, address, email, phone, website, social_media, note, status FROM customers WHERE 1";

// Add conditions based on filter values
if (!empty($id)) {
    $query .= " AND id LIKE '%" . $conn->real_escape_string($id) . "%'";
}if (!empty($name)) {
    $query .= " AND name LIKE '%" . $conn->real_escape_string($name) . "%'";
}
if (!empty($company_name)) {
    $query .= " AND company_name LIKE '%" . $conn->real_escape_string($company_name) . "%'";
}
if (!empty($address)) {
    $query .= " AND address LIKE '%" . $conn->real_escape_string($address) . "%'";
} 
if (!empty($email)) {
    $query .= " AND email LIKE '%" . $conn->real_escape_string($email) . "%'";
} 
if (!empty($phone)) {
    $query .= " AND phone LIKE '%" . $conn->real_escape_string($phone) . "%'";
} 
if (!empty($website)) {
    $query .= " AND website LIKE '%" . $conn->real_escape_string($website) . "%'";
} 
if (!empty($social_media)) {
    $query .= " AND social_media LIKE '%" . $conn->real_escape_string($social_media) . "%'";
} 
if (!empty($note)) {
    $query .= " AND note LIKE '%" . $conn->real_escape_string($note) . "%'";
}
if (!empty($status)) {
    $query .= " AND status = '" . $conn->real_escape_string($status) . "'";
}

// Count total rows for pagination
$totalQuery = "SELECT COUNT(*) as total FROM ($query) AS totalData";
$totalResult = $conn->query($totalQuery);
$totalRows = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $rowsPerPage);

// Add LIMIT for pagination
$query .= " LIMIT $rowsPerPage OFFSET $offset";

// Execute the query and fetch the results
$result = $conn->query($query);

// Debugging: Output the query and number of rows
//echo "Query: " . $query . "<br>";
//echo "Number of results: " . $result->num_rows . "<br>";

// Check if there are results
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "
        <tr data-id='{$row['id']}'>
            <td><input type='checkbox' name='selectRow' value='{$row['id']}'></td>
            <td>{$row['id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['company_name']}</td>
            <td>{$row['address']}</td>
            <td>{$row['email']}</td>
            <td>{$row['phone']}</td>
            <td>{$row['website']}</td>
            <td>{$row['social_media']}</td>
            <td>{$row['note']}</td>
            <td>{$row['status']}</td>
            <td>
                <button class='btn btn-warning btn-sm edit-btn' data-id='{$row['id']}'>Edit </button>
                <button class='btn btn-danger btn-sm delete-btn' data-id='{$row['id']}'>Delete</button>
            </td>
        </tr>
        <tr class='edit-row' id='edit-row-{$row['id']}']}' style='display: none;'>
            <td colspan='12'>
                <form id='edit-form-{$row['id']}'>
                    <input type='hidden' name='id' value='{$row['id']}'>
                    <div class='row'>
                        <div class='col-md-3'>
                            <label class='form-label'>Name</label>
                            <input type='text' name='name' class='form-control' value='{$row['name']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Company Name</label>
                            <input type='text' name='company_name' class='form-control' value='{$row['company_name']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Address</label>
                            <input type='text' name='address' class='form-control' value='{$row['address']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Email</label>
                            <input type='text' name='email' class='form-control' value='{$row['email']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Phone</label>
                            <input type='text' name='phone' class='form-control' value='{$row['phone']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Website</label>
                            <input type='text' name='website' class='form-control' value='{$row['website']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Social Media</label>
                            <input type='text' name='social_media' class='form-control' value='{$row['social_media']}'>
                        </div>
                        <div class='col-md-3'>
                            <label class='form-label'>Note</label>
                            <input type='text' name='note' class='form-control' value='{$row['note']}'>
                        </div>
                        <div class='col-md-2'>
                            <label class='form-label'>Status</label>
                            <select name='status' class='form-select'>
                                <option value='good' " . ($row['status'] == 'good' ? 'selected' : '') . ">Good</option>
                                <option value='bad' " . ($row['status'] == 'bad' ? 'selected' : '') . ">Bad</option>
                                <option value='approved' " . ($row['status'] == 'approved' ? 'selected' : '') . ">Approved</option>
                                <option value='verified' " . ($row['status'] == 'verified' ? 'selected' : '') . ">Verified</option>
                                <option value='ongoing' " . ($row['status'] == 'ongoing' ? 'selected' : '') . ">Ongoing</option>
                                <option value='pending' " . ($row['status'] == 'pending' ? 'selected' : '') . ">Pending</option>
                                <option value='in_progress' " . ($row['status'] == 'in_progress' ? 'selected' : '') . ">In Progress</option>
                                <option value='under_review' " . ($row['status'] == 'under_review' ? 'selected' : '') . ">Under Review</option>
                                <option value='awaiting_approval' " . ($row['status'] == 'awaiting_approval' ? 'selected' : '') . ">Awaiting Approval</option>
                                <option value='processing' " . ($row['status'] == 'processing' ? 'selected' : '') . ">Processing</option>
                                <option value='on_hold' " . ($row['status'] == 'on_hold' ? 'selected' : '') . ">On hold</option>
                                <option value='successful' " . ($row['status'] == 'successful' ? 'selected' : '') . ">Successful</option>
                                <option value='complete' " . ($row['status'] == 'complete' ? 'selected' : '') . ">CompleteBad</option>
                                <option value='cancelled' " . ($row['status'] == 'cancelled' ? 'selected' : '') . ">Cancelled</option>
                                <option value='refunded' " . ($row['status'] == 'refunded' ? 'selected' : '') . ">Refunded</option>
                                <option value='failed' " . ($row['status'] == 'failed' ? 'selected' : '') . ">Failed</option>
                                <option value='expired' " . ($row['status'] == 'expired' ? 'selected' : '') . ">Expired</option>
                            </select>
                        </div>
                        <div class='col-md-1'>
                            <button type='button' class='btn btn-success save-btn mt-1 mb-1' data-id='{$row['id']}'>Save</button>
                            <button class='btn btn-warning btn-sm edit-btn' data-id='{$row['id']}'>Cancel </button>
                        </div>
                    </div>
                </form>
            </td>
        </tr>
        
        ";
    }
} else {
    echo "<tr><td colspan='12' class='text-center'>No records found</td></tr>";
}

// Return pagination controls
echo "<tr><td colspan='12' class='text-center'>";
for ($i = 1; $i <= $totalPages; $i++) {
    echo "<button class='pagination-btn' data-page='$i'>$i</button> ";
}
echo "</td></tr>";

// Close the database connection
$conn->close();

?>