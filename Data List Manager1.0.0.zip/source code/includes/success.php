<?php
// Ensure this script is executed only via GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // Define the path to the install directory
    $install_folder = "../install";

    // Check if the install folder exists
    if (is_dir($install_folder)) {
        // Try to delete the install folder
        if (deleteFolder($install_folder)) {
            // Installation successful, redirect to the home page
            header("Location: ../index.php"); // Redirect to index.php
            exit(); // Prevent further script execution
        } else {
            echo "Failed to delete the install folder. Please remove it manually.";
        }
    } else {
        echo "Install folder not found. Installation may already be completed.";
    }
}

// Function to recursively delete a folder and its contents
function deleteFolder($folder) {
    // Get all files and directories in the folder, excluding special entries
    $files = array_diff(scandir($folder), array('.', '..'));

    foreach ($files as $file) {
        $filePath = $folder . DIRECTORY_SEPARATOR . $file;

        // Check if it's a directory and handle recursively
        if (is_dir($filePath)) {
            if (!deleteFolder($filePath)) {
                return false; // Return false if deletion fails
            }
        } else {
            // Delete individual files
            if (!unlink($filePath)) {
                return false; // Return false if deletion fails
            }
        }
    }

    // Delete the folder itself
    return rmdir($folder); // Returns true on success, false on failure
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Success</title>
</head>
<body>
    <h1>Installation Completed!</h1>
    <p>Your application has been successfully installed.</p>
    <p>You can now log in using the admin credentials you provided.</p>
</body>
</html>
