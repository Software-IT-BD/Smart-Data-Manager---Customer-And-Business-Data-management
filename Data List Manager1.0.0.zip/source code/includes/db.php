<?php
$host = 'localhost';
$db_username = 'root'; // Ensure this matches your MySQL username
$db_password = ''; // Ensure this matches your MySQL password
$database = 'data'; // Ensure the database name is correct

function connectDatabase($host, $db_username, $db_password, $database) {
    try {
        $conn = new mysqli($host, $db_username, $db_password, $database);

        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        return $conn;
    } catch (Exception $e) {
        // Log the error for debugging purposes
        error_log($e->getMessage());
        return false; // Return false if connection fails
    }
}

?>
