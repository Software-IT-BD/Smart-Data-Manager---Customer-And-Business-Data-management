<?php
session_start(); // Start the session
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if not logged in
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$userFullName = $_SESSION['user_full_name']; // Get full name from session
$userid = $_SESSION['user_id']; // Get id from session

?>
<!-- header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Management System</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>
<header class="bg-primary text-white">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid p-0 main-content"" id="header_fullscreen">
            <a class="navbar-brand" id="header-toggle-sidebar" href="#">
                <button class="btn btn-primary" id="toggle-sidebar">☰</button>
            </a>
            <div class="d-flex align-items-center ms-auto">
                <div class="me-3">
                    <span id="currentDateTime"></span>
                    <i class="bi bi-person-circle"></i>
                </div>
                <div class="dropdown">
                    <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> <?= htmlspecialchars($userFullName) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>user/edit_user.php?id=<?= htmlspecialchars($userid) ?>">User Edit</a></li>
                        <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</header>

