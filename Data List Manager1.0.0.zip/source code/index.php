<?php
/**
 * @package Data List Manager - Customer And Business Data list management
 * @author Software IT
 * @license http://codecanyon.net/licenses
 * @version 1.0.0
 */

include 'includes/db.php'; // Including the database connection file

// installation check
if (!$conn) {
    header('Location: install');
    exit(); // Ensure no further code is executed
}

// Fetch distinct values for dropdown filters
$id = mysqli_query($conn, "SELECT DISTINCT id FROM customers WHERE id IS NOT NULL");
$name = mysqli_query($conn, "SELECT DISTINCT name FROM customers WHERE name IS NOT NULL");
$company_name = mysqli_query($conn, "SELECT DISTINCT company_name FROM customers WHERE company_name IS NOT NULL");
$address = mysqli_query($conn, "SELECT DISTINCT address FROM customers WHERE address IS NOT NULL");
$email = mysqli_query($conn, "SELECT DISTINCT email FROM customers WHERE email IS NOT NULL");
$phone = mysqli_query($conn, "SELECT DISTINCT phone FROM customers WHERE phone IS NOT NULL");
$website = mysqli_query($conn, "SELECT DISTINCT website FROM customers WHERE website IS NOT NULL");
$social_media = mysqli_query($conn, "SELECT DISTINCT social_media FROM customers WHERE social_media IS NOT NULL");
$note = mysqli_query($conn, "SELECT DISTINCT note FROM customers WHERE note IS NOT NULL");
$status = mysqli_query($conn, "SELECT DISTINCT status FROM customers WHERE status IS NOT NULL");




// Set default values for rows per page and current page
$rowsPerPage = isset($_GET['rowsPerPage']) ? max((int)$_GET['rowsPerPage'], 1) : 10;
$page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;

// Calculate the offset for SQL query
$offset = ($page - 1) * $rowsPerPage;

// Fetch the total number of rows
$totalRowsResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM customers");
$totalRows = mysqli_fetch_assoc($totalRowsResult)['total'];

// Calculate total pages
$totalPages = ceil($totalRows / $rowsPerPage);

// Fetch data for the current page
$sql = "SELECT * FROM customers LIMIT $rowsPerPage OFFSET $offset";
$result = mysqli_query($conn, $sql);

include 'header.php';
?>

<div class="d-flex">
	<!-- Sidebar -->
	<?php
		include 'sidebar.php';
	?>
	<!-- Main Content -->
	<div class="container-fluid p-4 main-content" id="main-content">
		
		<h1 class="pb-3 pt-3">Data List</h1>
		<!-- Filter Section -->
		<div class="card mb-4">
			<div class="card-header bg-primary text-white"><h4>Filter</h4></div>
			<div class="card-body">
				<form id="filter-form" class="row g-3">
					<div class="col-md-3">
						<label for="bulk-name" class="form-label">Name</label>
						<input type="text" id="name" name="name" class="form-control" placeholder="Name">
					</div>
					<div class="col-md-3">
						<label for="bulk-company_name" class="form-label">Company Name</label>
						<input type="text" id="company_name" name="company_name" class="form-control" placeholder="Company Name">
					</div>
					<div class="col-md-3">
						<label for="bulk-address" class="form-label">Address</label>
						<input type="text" id="address" name="address" class="form-control" placeholder="Address">
					</div>
					<div class="col-md-3">
						<label for="bulk-email" class="form-label">Email</label>
						<input type="text" id="email" name="email" class="form-control" placeholder="Email">
					</div>
					<div class="col-md-3">
						<label for="bulk-phone" class="form-label">Phone</label>
						<input type="text" id="phone" name="phone" class="form-control" placeholder="Phone">
					</div>
					<div class="col-md-3">
						<label for="bulk-website" class="form-label">Website</label>
						<input type="text" id="website" name="website" class="form-control" placeholder="Website">
					</div>
					<div class="col-md-3">
						<label for="bulk-social_media" class="form-label">Social Media</label>
						<input type="text" id="social_media" name="social_media" class="form-control" placeholder="Social Media">
					</div>
					<div class="col-md-3">
						<label for="bulk-note" class="form-label">Note</label>
						<input type="text" id="note" name="note" class="form-control" placeholder="Note">
					</div>
					<div class="col-md-3">
						<label for="bulk-status" class="form-label">Status</label><br>
						<select id="status" name="status" class="form-select p-2">
							<label for="bulk-status" class="form-label">Status</label>
							<option value="">Select Status</option>
							<?php while ($row = mysqli_fetch_assoc($status)): ?>
								<option value="<?= htmlspecialchars($row['status']) ?>"><?= htmlspecialchars($row['status']) ?></option>
							<?php endwhile; ?>
						</select>
					</div>
					<div  class="p-2 col-12">
						<button type="button" id="apply-filters" class="btn btn-primary w-100">Apply Filters</button>
					</div>
				</form>
			</div>
		</div>

		<!-- Bulk Update Section -->
		<div class="card mb-4">
			<div class="card-header bg-success text-white"><h4>Bulk Update</h4></div>
			<div class="card-body">
				<form id="bulk-update-form" class="row g-3">
					<div class="col-md-3">
						<label for="bulk-company_name" class="form-label">Company Name</label>
						<div class="input-group">
							<input type="text" id="bulk-company_name" class="form-control" placeholder="Enter Company Name">
							<button type="button" class="btn btn-success" onclick="bulkUpdateField('company_name')">Update</button>
						</div>
					</div>
					<div class="col-md-3">
						<label for="bulk-address" class="form-label">Address</label>
						<div class="input-group">
							<input type="text" id="bulk-address" class="form-control" placeholder="Enter Address">
							<button type="button" class="btn btn-success" onclick="bulkUpdateField('address')">Update</button>
						</div>
					</div>
					<div class="col-md-3">
						<label for="bulk-note" class="form-label">note</label>
						<div class="input-group">
							<input type="text" id="bulk-note" class="form-control" placeholder="Enter note">
							<button type="button" class="btn btn-success" onclick="bulkUpdateField('note')">Update</button>
						</div>
					</div>
					<div class="col-md-3">
						<label for="bulk-status" class="form-label">Status</label>
						<div class="input-group">
							<select id="bulk-status" class="form-select">
								<option value="">Select Status</option>
								<option value="good">Good</option>
								<option value="bad">Bad</option>
								<option value="Approved">Approved</option>
								<option value="Verified">Verified</option>
								<option value="Ongoing">Ongoing</option>
								<option value="Pending">Pending</option>
								<option value="In Progress">In Progress</option>
								<option value="Under Review">Under Review</option>
								<option value="Awaiting Approval">Awaiting Approval</option>
								<option value="Processing">Processing</option>
								<option value="On hold">On hold</option>
								<option value="Successful">Successful</option>
								<option value="Complete">Complete</option>
								<option value="Cancelled">Cancelled</option>
								<option value="Refunded">Refunded</option>
								<option value="Failed">Failed</option>
								<option value="Expired">Expired</option>
							</select>
							<button type="button" class="btn btn-success" onclick="bulkUpdateField('status')">Update</button>
						</div>
					</div>
				</form>
			</div>
			<div class="mt-3 mb-4 text-center col-md-3">
					<button type="button" class="btn btn-danger w-100" onclick="bulkDelete()">Delete Selected</button>
			</div>
		</div>

		<!-- Add Pagination and Rows Per Page UI -->
		<div class="row mb-6">
			<div class="col-md-6">
				<form id="rows-per-page-form">
					<div><label for="rowsPerPage">Show per page:</label></div>
					<input type="number" id="rowsPerPage" name="rowsPerPage" value="10" class="form-control  mb-3" style="width: 100px; float: left;" min="1">
					<button type="submit" class="btn btn-primary mb-3">Update</button>
				</form>
			</div>
		</div>

		<!-- Table Data Section -->
		<div class="table-responsive mb-4" id="tableDataSection">
			<table id="data-table" class="table table-bordered table-hover">
				<thead class="table-light">
					<tr>
						<th><input type="checkbox" id="select-all"></th>
						<th>id</th>
						<th>Name</th>
						<th>Company Name</th>
						<th>Address</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Website</th>
						<th>Social Media</th>
						<th>Note</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				<?php while ($row = mysqli_fetch_assoc($result)): ?>
					
							<tr data-id='<?= htmlspecialchars($row['id']) ?>'>
								<td><input type="checkbox" name="selectRow" value="<?= htmlspecialchars($row['id']) ?>"></td>
								<td><?= htmlspecialchars($row['id']) ?></td>
								<td><?= htmlspecialchars($row['name']) ?></td>
								<td><?= htmlspecialchars($row['company_name']) ?></td>
								<td><?= htmlspecialchars($row['address']) ?></td>
								<td><?= htmlspecialchars($row['email']) ?></td>
								<td><?= htmlspecialchars($row['phone']) ?></td>
								<td><?= htmlspecialchars($row['website']) ?></td>
								<td><?= htmlspecialchars($row['social_media']) ?></td>
								<td><?= htmlspecialchars($row['note']) ?></td>
								<td><?= htmlspecialchars($row['status']) ?></td>
								<td>
									<button class='btn btn-warning btn-sm edit-btn' data-id='<?= htmlspecialchars($row['id']) ?>'>Edit</button>
									<button class='btn btn-danger btn-sm delete-btn' data-id='<?= htmlspecialchars($row['id']) ?>'>Delete</button>
								</td>
							</tr>
							<tr class='edit-row' id='edit-row-<?= htmlspecialchars($row['id']) ?>']}' style='display: none;'>
								<td colspan='12'>
									<form id='edit-form-<?= htmlspecialchars($row['id']) ?>'>
										<input type='hidden' name='id' value='<?= htmlspecialchars($row['id']) ?>'>
										<div class='row'>
											<div class='col-md-3'>
											<label class="form-label">Name</label>
												<input type='text' name='name' class='form-control' value='{$row['name']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Company Name</label>
												<input type='text' name='company_name' class='form-control' value='{$row['company_name']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Address</label>
												<input type='text' name='address' class='form-control' value='{$row['address']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Email</label>
												<input type='text' name='email' class='form-control' value='{$row['email']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Phone</label>
												<input type='text' name='phone' class='form-control' value='{$row['phone']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Website</label>
												<input type='text' name='website' class='form-control' value='{$row['website']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Social Media</label>
												<input type='text' name='social_media' class='form-control' value='{$row['social_media']}'>
											</div>
											<div class='col-md-3'>
												<label class="form-label">Note</label>
												<input type='text' name='note' class='form-control' value='{$row['note']}'>
											</div>
											<div class='col-md-2'>
												<label class="form-label">Status</label>
												<select name='status' class='form-select'>
													<option value='good' " . ($row['status'] == 'good' ? 'selected' : '') . ">Good</option>
													<option value='bad' " . ($row['status'] == 'bad' ? 'selected' : '') . ">Bad</option>
													<option value='approved' " . ($row['status'] == 'approved' ? 'selected' : '') . ">Approved</option>
													<option value='verified' " . ($row['status'] == 'verified' ? 'selected' : '') . ">Verified</option>
													<option value='ongoing' " . ($row['status'] == 'ongoing' ? 'selected' : '') . ">Ongoing</option>
													<option value='pending' " . ($row['status'] == 'pending' ? 'selected' : '') . ">Pending</option>
													<option value='in_progress' " . ($row['status'] == 'in_progress' ? 'selected' : '') . ">In Progress</option>
													<option value='under_review' " . ($row['status'] == 'under_review' ? 'selected' : '') . ">Under Review</option>
													<option value='awaiting_approval' " . ($row['status'] == 'awaiting_approval' ? 'selected' : '') . ">Awaiting Approval</option>
													<option value='processing' " . ($row['status'] == 'processing' ? 'selected' : '') . ">Processing</option>
													<option value='on_hold' " . ($row['status'] == 'on_hold' ? 'selected' : '') . ">On hold</option>
													<option value='successful' " . ($row['status'] == 'successful' ? 'selected' : '') . ">Successful</option>
													<option value='complete' " . ($row['status'] == 'complete' ? 'selected' : '') . ">Complete</option>
													<option value='cancelled' " . ($row['status'] == 'cancelled' ? 'selected' : '') . ">Cancelled</option>
													<option value='refunded' " . ($row['status'] == 'refunded' ? 'selected' : '') . ">Refunded</option>
													<option value='failed' " . ($row['status'] == 'failed' ? 'selected' : '') . ">Failed</option>
													<option value='expired' " . ($row['status'] == 'expired' ? 'selected' : '') . ">Expired</option>
												</select>
											</div>
											<div class='col-md-1'>
												<button type='button' class='btn btn-success save-btn mt-1 mb-1' data-id='<?= htmlspecialchars($row['id']) ?>'>Save</button>
												<button class='btn btn-warning btn-sm edit-btn' data-id='<?= htmlspecialchars($row['id']) ?>'>Cancel</button>
											</div>
										</div>
									</form>
								</td>
							</tr>
						<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
// Including the footer
include 'footer.php';
?>