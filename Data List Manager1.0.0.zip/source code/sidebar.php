<!-- Sidebar -->
<div class="sidebar bg-dark text-light p-3" id="sidebar">
    <button class="btn btn-danger" id="close-sidebar" style="display: none;">X</button>
    <span class="navbar-text">
        Welcome, <strong><?php echo htmlspecialchars($userFullName); ?></strong>
    </span>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a href="<?php echo BASE_URL; ?>" class="nav-link text-light">Data List</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo BASE_URL; ?>add-data/add_data.php" class="nav-link text-light">Add Data</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo BASE_URL; ?>add-data/add_data_excel.php" class="nav-link text-light">Import Data Excel</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo BASE_URL; ?>user/user_list.php" class="nav-link text-light">User</a>
        </li>
        <li class="nav-item">
            <a href="<?php echo BASE_URL; ?>user/add_user.php" class="nav-link text-light">Add User</a>
        </li>
            <li class="nav-item text-left mt-3">
            <a href="<?php echo BASE_URL; ?>logout.php" class="btn btn-danger">Logout</a>
        </li>
    </ul>
</div>